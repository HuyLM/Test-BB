using UnityEngine;

namespace PopJet
{
    /// <summary>
    /// Gắn âm thanh + particle vào sự kiện của bóng (tối thiểu 2 kênh phản hồi: audio + VFX).
    /// Particle nên phát theo hướng +Y local (script sẽ xoay +Y về hướng khí thoát).
    /// </summary>
    [RequireComponent(typeof(BalloonController))]
    public class BalloonFeedback : MonoBehaviour
    {
        [Header("Audio")]
        [SerializeField] AudioSource source;
        [Tooltip("Nên có từ 3 clip trở lên để tránh lặp.")]
        [SerializeField] AudioClip[] ventClips;
        [SerializeField] AudioClip[] leakClips;
        [SerializeField] AudioClip[] patchClips;
        [SerializeField] AudioClip emptyClip;
        [SerializeField] AudioClip goalClip;
        [SerializeField] Vector2 pitchRange = new Vector2(0.92f, 1.08f);

        [Header("VFX")]
        [SerializeField] ParticleSystem ventPuffPrefab;
        [SerializeField] ParticleSystem leakPuffPrefab;
        [SerializeField] ParticleSystem patchPuffPrefab;

        BalloonController balloon;

        void Awake()
        {
            balloon = GetComponent<BalloonController>();
            if (source == null) source = GetComponent<AudioSource>();
        }

        void OnEnable()
        {
            balloon.VentStarted += OnVent;
            balloon.LeakAdded += OnLeak;
            balloon.PatchedUp += OnPatched;
            balloon.BecameEmpty += OnEmpty;
            balloon.GoalReached += OnGoal;
        }

        void OnDisable()
        {
            balloon.VentStarted -= OnVent;
            balloon.LeakAdded -= OnLeak;
            balloon.PatchedUp -= OnPatched;
            balloon.BecameEmpty -= OnEmpty;
            balloon.GoalReached -= OnGoal;
        }

        void OnVent(Vector2 pos, Vector2 flyDir)
        {
            PlayRandom(ventClips);
            Spawn(ventPuffPrefab, pos, -flyDir);
        }

        void OnLeak(Vector2 pos, Vector2 flyDir)
        {
            PlayRandom(leakClips);
            Spawn(leakPuffPrefab, pos, -flyDir);
        }

        void OnPatched()
        {
            PlayRandom(patchClips);
            Spawn(patchPuffPrefab, balloon.Center, Vector2.up);
        }

        void OnEmpty() { PlayOne(emptyClip); }
        void OnGoal() { PlayOne(goalClip); }

        void PlayRandom(AudioClip[] clips)
        {
            if (source == null || clips == null || clips.Length == 0) return;
            PlayOne(clips[Random.Range(0, clips.Length)]);
        }

        void PlayOne(AudioClip clip)
        {
            if (source == null || clip == null) return;
            source.pitch = Random.Range(pitchRange.x, pitchRange.y);
            source.PlayOneShot(clip);
        }

        void Spawn(ParticleSystem prefab, Vector2 pos, Vector2 outward)
        {
            if (prefab == null) return;
            var rot = Quaternion.FromToRotation(Vector3.up, outward);
            var ps = Instantiate(prefab, pos, rot);
            Destroy(ps.gameObject, 2f);
        }
    }
}
