using UnityEngine;

namespace PopJet
{
    /// <summary>Overlay debug nhỏ để tune: trạng thái, khí, số lỗ rò. Xóa khi build thật.</summary>
    public class PopJetDebug : MonoBehaviour
    {
        [SerializeField] BalloonController balloon;
        [SerializeField] int fontSize = 36;

        GUIStyle style;

        void OnGUI()
        {
            if (balloon == null) return;
            if (style == null)
            {
                style = new GUIStyle(GUI.skin.label) { fontSize = fontSize };
                style.normal.textColor = Color.white;
            }
            GUI.Label(new Rect(20, 20, 900, 200),
                $"State: {balloon.State}\nAir: {balloon.Air01:0.00}\nVents: {balloon.VentCount}  Leaks: {balloon.LeakCount}",
                style);
        }
    }
}
