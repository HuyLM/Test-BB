using UnityEngine;
using UnityEngine.Events;
using UnityEngine.SceneManagement;

namespace PopJet
{
    /// <summary>
    /// Điều phối màn chơi: hết khí = thất bại mềm (tự chơi lại sau một chút),
    /// chạm đích = thắng. UI (panel thắng, nút Next/Retry) nối qua UnityEvent hoặc gọi Restart/LoadNext.
    /// </summary>
    public class LevelManager : MonoBehaviour
    {
        [SerializeField] BalloonController balloon;
        [SerializeField] float failRestartDelay = 1.5f;
        [Tooltip("Tên scene màn kế tiếp (phải có trong Build Settings). Để trống nếu dùng UI để chuyển.")]
        [SerializeField] string nextSceneName;
        [SerializeField] bool autoLoadNextOnWin = false;
        [SerializeField] float winDelay = 1.2f;
        [SerializeField] UnityEvent onFail;
        [SerializeField] UnityEvent onWin;

        void OnEnable()
        {
            if (balloon == null) return;
            balloon.BecameEmpty += HandleEmpty;
            balloon.GoalReached += HandleGoal;
        }

        void OnDisable()
        {
            if (balloon == null) return;
            balloon.BecameEmpty -= HandleEmpty;
            balloon.GoalReached -= HandleGoal;
        }

        void HandleEmpty()
        {
            onFail?.Invoke();
            Invoke(nameof(Restart), failRestartDelay);
        }

        void HandleGoal()
        {
            onWin?.Invoke();
            if (autoLoadNextOnWin && !string.IsNullOrEmpty(nextSceneName))
                Invoke(nameof(LoadNext), winDelay);
        }

        public void Restart()
        {
            CancelInvoke();
            SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);
        }

        public void LoadNext()
        {
            if (!string.IsNullOrEmpty(nextSceneName))
                SceneManager.LoadScene(nextSceneName);
        }
    }
}
